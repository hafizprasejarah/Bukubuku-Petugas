package com.example.bukubuku_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}