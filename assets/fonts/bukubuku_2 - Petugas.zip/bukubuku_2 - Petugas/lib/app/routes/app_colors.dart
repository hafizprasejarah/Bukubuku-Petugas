import 'package:flutter/material.dart';


const TextColor = Color(0xFF535353);
const TextLightColor = Color(0xFFACACAC);
const BgColor = Color(0xFF3B62FE);
const DefaultPadding = 20.0;

