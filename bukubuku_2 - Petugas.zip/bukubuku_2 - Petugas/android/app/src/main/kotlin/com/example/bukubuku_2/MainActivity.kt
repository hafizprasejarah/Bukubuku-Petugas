package com.example.bukubuku_2

import io.flutter.embedding.android.FlutterActivity
import androidx.core.content.FileProvider;


class MainActivity: FlutterActivity() {
}